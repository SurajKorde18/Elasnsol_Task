import {useState} from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom';

const Register = () => {
    const [formData, setFormData] = useState({ name: '', dob: '', email: '', password: '' });
    const navigate = useNavigate();
    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    }

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.post('http://localhost:5000/api/auth/register', formData);
            alert('Registration successful!');
            navigate("/dashboard");
            
        } catch (error) {
            alert(error.response.data.error);
        }
    }
    return (
    <div>
        <form onSubmit={handleSubmit}>
            <h2>Register</h2>
            <input type="text" name="name" onChange={handleChange} placeholder="Name" />
            <input type="date" name="dob" onChange={handleChange} placeholder="Date of Birth" />
            <input type="email" name="email" onChange={handleChange} placeholder="Email" />
            <input type="password" name="password" onChange={handleChange} placeholder="Password" />
            <button type="submit">Register</button>
        </form>
    </div>
  )
}

export default Register